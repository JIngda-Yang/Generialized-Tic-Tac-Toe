package GTTT;

public class Main {

	public static void main(String[] args) {

		//AIvsAI
		//Set up parameters
		//Set up games
	    Game game = new Game(18,5);
	    game.AIvsAI();
	}

}
